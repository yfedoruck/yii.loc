<?php

/**
 * Dropbox Exception class
 * @author Ben Tadiar <ben@handcraftedbyben.co.uk>
 * @link https://github.com/benthedesigner/dropbox
 * @package Dropbox
 */
namespace Dropbox;

class Exception extends \Exception
{

}
