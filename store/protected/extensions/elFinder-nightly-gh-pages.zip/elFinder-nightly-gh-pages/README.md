# elFinder nightly builds

These nightly builds are made automatically from "Studio-42/elFinder:2.1, Studio-42/elFinder:2.x and nao-pon/elFinder:2.x_n" on the hour.

* [Studio-42/elFinder](https://github.com/Studio-42/elFinder): 2.x & 2.1
* [nao-pon/elFinder](https://github.com/nao-pon/elFinder): 2.x_n & 2.1_n

## Download latest packages

* [elFinder 2.x](http://nao-pon.github.io/elFinder-nightly/latests/elfinder-2.x.zip)
* [elFinder 2.1](http://nao-pon.github.io/elFinder-nightly/latests/elfinder-2.1.zip)
* [elFinder 2.x_n](http://nao-pon.github.io/elFinder-nightly/latests/elfinder-2.x_n.zip)
* [elFinder 2.1_n](http://nao-pon.github.io/elFinder-nightly/latests/elfinder-2.1_n.zip)
